/**
 * Basic access to the Turtlebot 2 robot.
 * Copyright (C) 2015 Ana Cruz-Martín (anacruzmartin@gmail.com)
 *
 * DISCLAIMER: This is a work-in-progress test code, not finished yet.
 *
 * Based on the information and examples from this webs:
 *
 *   · http://wiki.ros.org/Robots/TurtleBot
 *   · https://github.com/turtlebot/turtlebot/blob/indigo/turtlebot_teleop/src/turtlebot_joy.cpp
 *   · http://answers.ros.org/question/47500/turtlebot-ros-moving-using-twist/
 *   · http://learn.turtlebot.com/
 *   · http://wiki.ros.org/kobuki/Tutorials/Examine%20Kobuki
 *   · https://github.com/yujinrobot/kobuki_msgs/blob/indigo/msg/SensorState.msg
 *   · http://docs.ros.org/jade/api/sensor_msgs/html/msg/Imu.html
 *
 */

#include "ros/ros.h"
#include "std_msgs/UInt16.h"
#include "std_msgs/UInt32.h"
#include "std_msgs/Header.h"
#include <assert.h>
#include <geometry_msgs/Twist.h>
#include <kobuki_msgs/Led.h>
#include <kobuki_msgs/SensorState.h>
#include <sensor_msgs/Imu.h>
#include <nav_msgs/Odometry.h>
#include <iostream>	
#include <fstream>

using namespace std;


/* 
Global variables where the sensory information will be temporary stored
Here, just the time, the left and right wheels encoder and the position of gyrometre will be save
You can create other variables in order to save more information
*/

std_msgs::UInt32 header_time_stamp_secs[10000];
std_msgs::UInt32 header_time_stamp_nsecs[10000];
std_msgs::UInt32 sensors_time_stamp[10000];

std_msgs::UInt32 sensors_left_encoder[10000];
std_msgs::UInt32 sensors_right_encoder[10000];

float Positionx[10000], Positiony[10000];
float Orientationx[10000], Orientationy[10000],Orientationz[10000],Orientationw[10000];

int sensors_index = 0, i=0,sensors_index_gyro = 0;



/*  
Callbacks for topics related to sensors and odometry
One function show the datas (on the terminal), the other store them in the global variables defined before
To store more datas, create global variables and implement the stores functions
*/
void showOdomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
  printf("Kobuki Odometry data\n");
  printf("\tSeq: [%d]\n", msg->header.seq);
  printf("\tPosition-> x: [%f], y: [%f], z: [%f]\n", msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
  printf("\tOrientation-> x: [%f], y: [%f], z: [%f], w: [%f]\n", msg->pose.pose.orientation.x, msg->pose.pose.orientation.y, msg->pose.pose.orientation.z, msg->pose.pose.orientation.w);
  printf("\tVel-> Linear: [%f], Angular: [%f]\n\n", msg->twist.twist.linear.x, msg->twist.twist.angular.z);
}

void storeOdomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
  Positionx[sensors_index_gyro] = msg->pose.pose.position.x;
  Positiony[sensors_index_gyro] = msg->pose.pose.position.y;
  Orientationx[sensors_index_gyro] = msg->pose.pose.orientation.x;
  Orientationy[sensors_index_gyro]= msg->pose.pose.orientation.y ;
  Orientationz[sensors_index_gyro]= msg->pose.pose.orientation.z;
  Orientationw[sensors_index_gyro]=  msg->pose.pose.orientation.w ;

  sensors_index_gyro += 1;
}

void showSensorsCallback(const kobuki_msgs::SensorState::ConstPtr& sensorsmsg)
{
   printf("Kobuki sensors data\n");
   printf("\tCore Data\n");  
   printf("\t\tTime stamp: %d\n", sensorsmsg->time_stamp);
   printf("\t\tBump: %d\n", sensorsmsg->bumper);
   printf("\t\tWheel drop: %d\n", sensorsmsg->wheel_drop);
   printf("\t\tCliff: %d\n", sensorsmsg->cliff);
   printf("\t\tLeft encoder: %d\n", sensorsmsg->left_encoder);
   printf("\t\tRight encoder: %d\n", sensorsmsg->right_encoder);
   printf("\t\tLeft pwm: %d\n", sensorsmsg->left_pwm);
   printf("\t\tRight pwm: %d\n", sensorsmsg->right_pwm);
   printf("\t\tButtons: %d\n", sensorsmsg->buttons);
   printf("\t\tCharger: %d\n", sensorsmsg->charger);
   printf("\t\tBattery: %d\n", sensorsmsg->battery);
   printf("\tCliff Data\n");  
   printf("\tCurrent Data\n");  
   printf("\t\tOver current: %d\n", sensorsmsg->over_current);
   printf("\tInput Data\n");  
   printf("\t\tDigital input: %d\n", sensorsmsg->digital_input);
}

void storeSensorsCallback(const kobuki_msgs::SensorState::ConstPtr& sensormsgs)
{
   header_time_stamp_secs[sensors_index].data = (sensormsgs -> header).stamp.sec;
   header_time_stamp_nsecs[sensors_index].data = (sensormsgs -> header).stamp.nsec;
   sensors_time_stamp[sensors_index].data = sensormsgs->time_stamp;
   sensors_left_encoder[sensors_index].data = sensormsgs->left_encoder;
   sensors_right_encoder[sensors_index].data = sensormsgs->right_encoder;

   sensors_index += 1;
}

void showImuCallback(const sensor_msgs::Imu::ConstPtr& imusmsg)
{
   printf("Imu data\n");
   printf("\tOrientation Data\n");  
   printf("\t\tCovariance x: %e %e %e\n",imusmsg->orientation_covariance[0],imusmsg->orientation_covariance[1],imusmsg->orientation_covariance[2]);
   printf("\t\tCovariance y: %e %e %e\n",imusmsg->orientation_covariance[3],imusmsg->orientation_covariance[4],imusmsg->orientation_covariance[5]);
   printf("\t\tCovariance z: %e %e %e\n",imusmsg->orientation_covariance[6],imusmsg->orientation_covariance[7],imusmsg->orientation_covariance[8]);
   printf("\tAngular velocity Data\n");  
   printf("\t\tCovariance x: %e %e %e\n",imusmsg->angular_velocity_covariance[0],imusmsg->angular_velocity_covariance[1],imusmsg->angular_velocity_covariance[2]);
   printf("\t\tCovariance y: %e %e %e\n",imusmsg->angular_velocity_covariance[3],imusmsg->angular_velocity_covariance[4],imusmsg->angular_velocity_covariance[5]);
   printf("\t\tCovariance z: %e %e %e\n",imusmsg->angular_velocity_covariance[6],imusmsg->angular_velocity_covariance[7],imusmsg->angular_velocity_covariance[8]);
   printf("\tLinear Acceleration Data\n");  
   printf("\t\tCovariance x: %e %e %e\n",imusmsg->linear_acceleration_covariance[0],imusmsg->linear_acceleration_covariance[1],imusmsg->linear_acceleration_covariance[2]);
   printf("\t\tCovariance y: %e %e %e\n",imusmsg->linear_acceleration_covariance[3],imusmsg->linear_acceleration_covariance[4],imusmsg->linear_acceleration_covariance[5]);
   printf("\t\tCovariance z: %e %e %e\n",imusmsg->linear_acceleration_covariance[6],imusmsg->linear_acceleration_covariance[7],imusmsg->linear_acceleration_covariance[8]);
}



// Auxiliary functions

/**
 * Stores the sensory data in a file.
 * Data obtained from different runnings are appened to the end of the file.
**/

void storeData(void)
{
  // Files where data from subscription topics are stored
  ofstream dataFile;
  //modify the directory
  dataFile.open("/home/turtlebot/catkin_ws/src/OdomPkg/test.txt");
  if (dataFile.is_open())
  {
     printf("Sensory data file opened OK\n");
     for(int i = 0; i < sensors_index && i< sensors_index_gyro; i++)
     {
        dataFile << header_time_stamp_secs[i].data << " " << header_time_stamp_nsecs[i].data << " "; 
        dataFile << sensors_time_stamp[i].data << " " << sensors_left_encoder[i].data << " " << sensors_right_encoder[i].data << " ";
	dataFile << Positionx[i]<<" "<< Positiony[i]<<" "<< Orientationx[i]<<" "<< Orientationy[i]<<" "<<Orientationz[i]<<" "<<Orientationw[1000]<<"\n";
     }
  }
  else printf("Error: sensory data file could not be opened\n");

  dataFile.close();
}


//moving functions
void goforward(ros::Publisher Mobile_base_vel, ros::Rate Loop_rate, geometry_msgs::Twist Twist, float Seconds, float Speed)
{
  time_t timeS = time(0);
  time_t timeE = time(0);	
  while ( timeE-timeS < Seconds){
      Twist.linear.x = Speed;
      ros::spinOnce();
      Loop_rate.sleep();
      Mobile_base_vel.publish(Twist);
      timeE = time(0);
      printf("going forward for %f seconds at %f m/sec\n ", Seconds, Speed);
  }
}

void turn_right(ros::Publisher Mobile_base_vel, ros::Rate Loop_rate, geometry_msgs::Twist Twist, float Seconds, float Speed, float Angle)
{
  time_t timeS = time(0);
  time_t timeE = time(0);	
  while ( timeE-timeS < Seconds){
      Twist.linear.x = Speed;
      Twist.angular.z = -Angle;
      ros::spinOnce();
      Loop_rate.sleep();
      Mobile_base_vel.publish(Twist);
      timeE = time(0);
      printf("Turning right for %f seconds at %f m/sec with an %f rad/sec angular speed\n ", Seconds, Speed, Angle);
  }
}

void turn_left(ros::Publisher Mobile_base_vel, ros::Rate Loop_rate, geometry_msgs::Twist Twist, float Seconds, float Speed, float Angle)
{
  time_t timeS = time(0);
  time_t timeE = time(0);	
  while ( timeE-timeS < Seconds){
      Twist.linear.x = Speed;
      Twist.angular.z = Angle;
      ros::spinOnce();
      Loop_rate.sleep();
      Mobile_base_vel.publish(Twist);
      timeE = time(0);
      printf("Turning left for %f seconds at %f m/sec with an %f rad/sec angular speed\n ", Seconds, Speed, Angle);
  }
}


// Main function. Comment/uncomment elements according to the tests to be deployed
int main(int argc, char **argv)
{

  ros::init(argc, argv , "kobuki_testing2");
  ros::NodeHandle n;
  
  

  // Subscribers  
// ros::Subscriber showOdom = n.subscribe("odom", 1000, showOdomCallback);
  ros::Subscriber storeOdom = n.subscribe("odom", 1000, storeOdomCallback);
//ros::Subscriber showSensors = n.subscribe("/mobile_base/sensors/core", 1000, showSensorsCallback);
  ros::Subscriber storeSensors = n.subscribe("/mobile_base/sensors/core", 1000, storeSensorsCallback);
//ros::Subscriber showImu = n.subscribe("/mobile_base/sensors/core", 1000, showImuCallback);

  // Publishers
  ros::Publisher mobile_base_led2= n.advertise<kobuki_msgs::Led>("/mobile_base/commands/led2", 1000);
  ros::Publisher mobile_base_vel = n.advertise<geometry_msgs::Twist>("/mobile_base/commands/velocity", 1000);
  ros::Rate loop_rate(10);

  // Messages for testing different mobile base elements
  geometry_msgs::Twist newTwist;
  geometry_msgs::PoseWithCovariance pose; 
  kobuki_msgs::Led led;  
  newTwist.linear.x = 0.0;
  newTwist.linear.y = 0.0;
  newTwist.linear.z = 0.0;
  newTwist.angular.x = 0.0;
  newTwist.angular.y = 0.0;
  newTwist.angular.z = 0.0;

//trajectory of the robot	
  goforward(mobile_base_vel, loop_rate, newTwist, 4, 0.30);

/*  turn_left(mobile_base_vel, loop_rate, newTwist, 8, 0.30, 0.075);
  turn_right(mobile_base_vel, loop_rate, newTwist, 8, 0.30, 0.075);
  goforward(mobile_base_vel, loop_rate, newTwist, 6, 0.30);
  turn_left(mobile_base_vel, loop_rate, newTwist, 11, 0.30, 0.3);
  goforward(mobile_base_vel, loop_rate, newTwist, 5, 0.30);
  turn_right(mobile_base_vel, loop_rate, newTwist, 5, 0.37, 0.165);
  turn_left(mobile_base_vel, loop_rate, newTwist, 5, 0.37, 0.165);
  goforward(mobile_base_vel, loop_rate, newTwist, 8, 0.30);
  turn_left(mobile_base_vel, loop_rate, newTwist, 13, 0.30, 0.19);
*/

//stop
  newTwist.linear.x = 0;

//store the datas to the file
  storeData();
  return 0;
}
